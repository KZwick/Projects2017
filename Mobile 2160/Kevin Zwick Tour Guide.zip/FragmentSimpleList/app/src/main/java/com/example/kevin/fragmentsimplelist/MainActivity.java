package com.example.kevin.fragmentsimplelist;

import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // do not Hide the side pane when in portrait mode
        int screenOrientation = getResources().getConfiguration().orientation;
        /*if (screenOrientation == Configuration.ORIENTATION_PORTRAIT) {
            hideSidePane();
        }*/
    }

    // Hides the side panel
    private void hideSidePane() {
        View sidePane = findViewById(R.id.fragment2);
        if (sidePane.getVisibility() == View.VISIBLE) {
            sidePane.setVisibility(View.GONE);
        }
    }

    public void sendData(){

    }
}

/*
 * Sources: https://www.youtube.com/watch?v=a07GtTjrE20 - List Fragment Example          *****
 *      https://www.youtube.com/watch?v=OLbsiE42JvE  - Fragment to fragment communication
 *      https://stackoverflow.com/questions/4161256
 *          /referencing-a-string-in-a-string-array-resource-with-xml
 *      https://developer.android.com/training/basics/fragments/creating.html
 *      https://developer.android.com/training/basics/fragments/communicating.html
 *      https://developer.android.com/guide/components/fragments.html                    *****
 *      https://github.com/aosp-mirror/platform_development/blob/master/samples
 *          /ApiDemos/src/com/example/android/apis/app/FragmentLayout.java
 *
 *      https://www.youtube.com/watch?v=Ve6oiF0SkFA
        https://www.youtube.com/watch?v=_Gra7aJ5UQ8
 *      http://www.newthinktank.com/2014/07/make-android-apps-12/
 *      http://www.newthinktank.com/2014/08/make-android-apps-13/
 *
 *      http://kb4dev.com/tutorial/android-layout/communication-between-fragments-in-android
 *
 *      TextFragment textFragment = new TextFragment();
 *      getSupportFragmentManager().beginTransaction().add(textFragment, null).commit();
 *
 *  Toast.makeText(getApplicationContext(),"Hello",Toast.LENGTH_SHORT).show();
 *  Toast.makeText(getActivity(),"Hello",Toast.LENGTH_SHORT).show();
 *
**/
