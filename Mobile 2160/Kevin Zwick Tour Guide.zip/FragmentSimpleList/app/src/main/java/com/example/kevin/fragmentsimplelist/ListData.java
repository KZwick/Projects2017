package com.example.kevin.fragmentsimplelist;

/**
 * Created by kevin on 2018-03-15.
 */

public class ListData {

    public static String[] listNames = {"Vancouver","Edmonton","Calgary","Ottawa",
            "Toronto","Halifax","Montreal","Quebec City","Fredericton"}; // 9 cities

    public static String listDetails[] = {"Vancouver: With its scenic views, mild climate, and friendly people, " +
            "Vancouver is known around the world as both a popular tourist attraction and one of the best places to live.\n" + "\n" +
            "Vancouver is also one of the most ethnically and linguistically diverse cities in Canada with 52 percent of the population speaking a first language other than English. \n" + "\n" +
            "Vancouver has hosted many international conferences and events, including the 2010 Winter Olympics and 2010 Winter Paralympics. \n" + "\n" +
            "Vancouver is a coastal seaport city in Canada, located in the Lower Mainland region of British Columbia. As the most populous city in the province, the 2016 census recorded 631,486 people in the city, up from 603,502 in 2011. The Greater Vancouver area had a population of 2,463,431 in 2016, making it the third-largest metropolitan area in Canada. Vancouver has the highest population density in Canada with over 5,400 people per square kilometre, which makes it the fourth-most densely populated city with over 250,000 residents in North America behind New York City, San Francisco, and Mexico City according to the 2011 census. Vancouver is one of the most ethnically and linguistically diverse cities in Canada according to that census; 52% of its residents have a first language other than English. Vancouver is classed as a Beta global city.",

            "Edmonton is the capital city of the Canadian province of Alberta. Edmonton is on the North Saskatchewan River and is the centre of the Edmonton Metropolitan Region, which is surrounded by Alberta's central region. The city anchors the north end of what Statistics Canada defines as the \"Calgary–Edmonton Corridor\".\n" +
            "The city had a population of 932,546 in 2016, making it Alberta's second-largest city and Canada's fifth-largest municipality. Also in 2016, Edmonton had a metropolitan population of 1,321,426, making it the sixth-largest census metropolitan area (CMA) in Canada. Edmonton is North America's northernmost city that has a metropolitan population over one million. A resident of Edmonton is known as an Edmontonian.",

            "Calgary is a city in the Canadian province of Alberta. It is situated at the confluence of the Bow River and the Elbow River in the south of the province, in an area of foothills and prairie, about 80 km east of the front ranges of the Canadian Rockies. The city anchors the south end of what Statistics Canada defines as the \"Calgary–Edmonton Corridor\".",

            "Ottawa is the capital city of Canada. It stands on the south bank of the Ottawa River in the eastern portion of southern Ontario. Ottawa borders Gatineau, Quebec; the two form the core of the Ottawa–Gatineau census metropolitan area (CMA) and the National Capital Region (NCR). As of 2016, Ottawa had a city population of 934,243 and a metropolitan population of 1,323,783 making it the fourth-largest city and the fifth-largest CMA in Canada.\n" +
            "Founded in 1826 as Bytown, and incorporated as Ottawa in 1855, the city has evolved into the political centre of Canada. Its original boundaries were expanded through numerous annexations and were ultimately replaced by a new city incorporation and amalgamation in 2001 which significantly increased its land area. The city name \"Ottawa\" was chosen in reference to the Ottawa River, the name of which is derived from the Algonquin Odawa, meaning \"to trade\".\n" +
            "Ottawa has the most educated population among Canadian cities[ and is home to a number of post-secondary, research, and cultural institutions, including the National Arts Centre, the National Gallery, and numerous national museums. Ottawa has the highest standard of living in the nation and low unemployment. It ranked 2nd nationally and 24th worldwide in the quality of life index and is consistently rated the best place to live in Canada.",

            "Toronto is the capital of the Canadian province of Ontario. It is located within the Golden Horseshoe in Southern Ontario on the northern shore of Lake Ontario. With 2,731,571 residents in 2016, it is the largest city in Canada and fourth-largest city in North America by population. Also in 2016, the Toronto census metropolitan area (CMA), the majority of which is within the Greater Toronto Area (GTA), had a population of 5,928,040, making it Canada’s most populous CMA. A global city, Toronto is a centre of business, finance, arts, and culture, and is recognized as one of the most multicultural and cosmopolitan cities in the world.",

            "Halifax legally known as the Halifax Regional Municipality (HRM), is the capital of the province of Nova Scotia, Canada. The municipality had a population of 403,131 in 2016, with 316,701 in the urban area centred on Halifax Harbour. The regional municipality consists of four former municipalities that were amalgamated in 1996: Halifax, Dartmouth, Bedford, and the Municipality of Halifax County." +
            "Halifax is a major economic centre in Atlantic Canada with a large concentration of government services and private sector companies. Major employers and economic generators include the Department of National Defence, Dalhousie University, Saint Mary's University, the Halifax Shipyard, various levels of government, and the Port of Halifax. Agriculture, fishing, mining, forestry and natural gas extraction are major resource industries found in the rural areas of the municipality. Halifax was ranked by MoneySense magazine as the fourth best place to live in Canada for 2012, placed first on a list of 'large cities by quality of life' and placed second in a list of 'large cities of the future', both conducted by fDi Magazine for North and South American cities .Additionally, Halifax has consistently placed in the top 10 for business friendliness of North and South American cities, as conducted by fDi Magazine.",

            "Montreal is the most populous municipality in the Canadian province of Quebec and the second-most populous municipality in Canada as a whole. Originally called Ville-Marie, or \"City of Mary\", it is named after Mount Royal, the triple-peaked hill in the heart of the city. The city is centred on the Island of Montreal, which took its name from the same source as the city, and a few much smaller peripheral islands, the largest of which is Île Bizard. It has a distinct four-season continental climate with warm to hot summers and cold, snowy winters.",

            "Quebec City is the capital city of the Canadian province of Quebec. The city had a population estimate of 531,902 in July 2016, (an increase of 3.0% from 2011) and the metropolitan area had a population of 800,296 in July 2016, (an increase of 4.3% from 2011) making it the second largest city in Quebec, after Montreal, and the seventh-largest metropolitan area in Canada.",

            "Fredericton is the capital of the Canadian province of New Brunswick. The city is situated in the west-central portion of the province along the Saint John River, which flows west to east as it bisects the city; it is the dominant natural feature of the area. One of the main urban centres in New Brunswick, the city had a population of 56,224 in the 2011 census. It is the third-largest city in the province after Moncton and Saint John."
    };  // 9 entries
}

/*
* http://vancouver.ca/about-vancouver.aspx, http://vancouver.ca/news-calendar/our-city.aspx
* https://en.wikipedia.org/wiki/Vancouver
* https://en.wikipedia.org/wiki/Edmonton
* https://en.wikipedia.org/wiki/Calgary
* https://en.wikipedia.org/wiki/Ottawa
* https://en.wikipedia.org/wiki/Toronto
* https://en.wikipedia.org/wiki/Halifax,_Nova_Scotia
* https://en.wikipedia.org/wiki/Montreal
* https://en.wikipedia.org/wiki/Quebec_City
* https://en.wikipedia.org/wiki/Fredericton
*
 */
