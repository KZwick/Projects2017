package com.example.kevin.fragmentsimplelist;

import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by kevin on 2018-03-15.
 */

public class FragmentList extends ListFragment {
    int mCurCheckPosition = 0;
    /*String listString[] = {"Vancouver","Edmonton","Calgary","Ottawa",
            "Toronto","Halifax","Montreal"};*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.list_fragment, container, false);

        //return super.onCreateView(inflater, container, savedInstanceState);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Populate list with our static array of titles.
        ArrayAdapter<String> connectArrayToListView = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_activated_1,
                ListData.listNames);

        // Connect the ListView to our data
        setListAdapter(connectArrayToListView);

        // fragment directly in the containing UI.
        View detailsFrame = getActivity().findViewById(R.id.text2);

        if (savedInstanceState != null) {
            // Restore last state for checked position.
            mCurCheckPosition = savedInstanceState.getInt("curChoice", 0);
        }

        // the list view highlights the selected item.
        getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // update the details fragment
        showDetails(mCurCheckPosition);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("curChoice", mCurCheckPosition);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // update the details fragment
        showDetails(position);;
    }

    void showDetails(int index) {
        mCurCheckPosition = index;

        //String toastOutput = "got to show details: " + index;
        //Toast.makeText(getActivity(),toastOutput, Toast.LENGTH_SHORT).show();

        // Update the list to highlight the selected item and show the data.
        getListView().setItemChecked(index, true);

        FragmentDetail details = (FragmentDetail) getFragmentManager().findFragmentById(R.id.fragment2);
        if(details == null || details.getShownIndex() != index){
            // Make new fragment to show this selection.
            details = FragmentDetail.newInstance(index);

            // Execute a transaction, replacing any existing fragment with this one inside the frame.
            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.fragment2, details);
            fragmentTransaction.commit();

        }

    }
}

/*
ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (getActivity(),android.R.layout.simple_list_item_1,listString);

        setListAdapter(adapter);
 */
/*DetailsFragment details = (DetailsFragment) getFragmentManager().findFragmentById(R.id.text2);
        if(details == null || details.getShownIndex() != index){
            // Make new fragment to show this selection.
            details = DetailsFragment.newInstance(index);
        }*/
