package com.example.kevin.fragmentsimplelist;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by kevin on 2018-03-15.
 */

public class FragmentDetail extends android.app.Fragment {

    public static FragmentDetail newInstance(int index){
        FragmentDetail fragmentDetail = new FragmentDetail();

        // Supply index input as an argument.
        Bundle args = new Bundle();
        args.putInt("index", index);
        fragmentDetail.setArguments(args);

        return fragmentDetail;
    }

    public int getShownIndex() {
        int result;
        result = getArguments().getInt("index", 0);

        //String toastOutput = "Shown Index is: " + result;
        //Toast.makeText(getActivity(),toastOutput, Toast.LENGTH_SHORT).show();

        return result;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //int result = ListData.listDetails.length;
        //String toastOutput = "Length of details array is: " + result;
        //Toast.makeText(getActivity(),toastOutput, Toast.LENGTH_SHORT).show();

        ScrollView scroller = new ScrollView(getActivity());
        TextView text = new TextView(getActivity());
        int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                4, getActivity().getResources().getDisplayMetrics());
        text.setPadding(padding, padding, padding, padding);
        scroller.addView(text);
        text.setText(ListData.listDetails[getShownIndex()]);

        return scroller;

    }
}

/*
@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.detail_fragment, container, false);

        return view;
   }

 */

